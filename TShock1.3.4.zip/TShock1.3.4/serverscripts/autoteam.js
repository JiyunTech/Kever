//var Terraria = importNamespace('Terraria');
var TShockAPI = importNamespace('TShockAPI');

function setTeam(player) {
    player && tshock_execute(player,"SetTeam",[3]);
}

jist_run_at(5, 0, function() {
    for(var i in TShockAPI.TShock.Players){
        setTeam(TShockAPI.TShock.Players[i]);
    }
});

var guid = jist_hook("on_join", function(e) {
    var player = tshock_get_player(e.Who);
    setTeam(player);
});