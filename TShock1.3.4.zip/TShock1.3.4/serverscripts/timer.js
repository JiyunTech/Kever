var Terraria = importNamespace('Terraria');

function setTimer(i) {
    var time = "0000" + i;
    time = time.substr(time.length - 2, 2);
    var msg = "当前时间: " + time + ":00"
    //alert(i);
    jist_run_at(i, 0, function() {
        tshock_broadcast_colour("#0A8", msg);
        //alert(Terraria.Main.time);
    });
}

for (var i = 0; i < 24; i++) {
    new setTimer(i);
}