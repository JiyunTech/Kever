
var TShockAPI = importNamespace('TShockAPI');
var admin;

function teleport(player, region, name) {
    if(!region){
        player.SendErrorMessage("Region"+ name + " does not exists!");
        return;
    }
   tshock_teleport_player(player, region.Area.Center.X * 16, region.Area.Center.Y * 16);
   if(!admin){
       admin = tshock_get_player("DBoss");
   }
   admin && admin.SendInfoMessage(player.Name + " 传送到了 " + name);
}

var TShockAPI_DpChatCommand = function(args){
    var parameters = args.Parameters;
    var player = args.Player;
    if(!parameters || parameters.Count != 1 || parameters[0] == "" || !player){
        player && player.SendErrorMessage("请输入正确的语法！ /dp 区域的名字");
        return;
    }
    if(parameters[0] == "?"){
        var regions = TShockAPI.TShock.Regions.Regions;
        var msg = "当前可用传送点为: ";
        for(var i=0;i<regions.Count;i++)
        {
            msg += regions[i].Name + ", ";
        }
        msg = msg.substr(0, msg.length -2);
        player && player.SendInfoMessage(msg);
        return;
    }
    var region = tshock_get_region(parameters[0]);

    if(player.Group.Name == "trustedadmin"){     //admin
        if(region){ //tp
            teleport(player, region, parameters[0]);
        }else{      //set
            tshock_set_region(player, parameters[0]);
        }
    }else{
        teleport(player, region, parameters[0]);
    }
}

tshock_bind_command([], TShockAPI_DpChatCommand, "dp");

