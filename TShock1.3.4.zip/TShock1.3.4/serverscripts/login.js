// tshock_bind_command([], function (args) {
//     var parameters = args.Parameters;
//     var player = args.Player;

//     if (parameters && parameters.Count > 0) {
//         var name = player.Name;
//         var password = parameters[0];
//         var sql = "select username from WebUsers where ";
//         sql += "username='" + name + "' and password='" + password + "'";
//         tshock_sql_query(sql, [], function (result) {
//             if (result && result.username == name) {
//             } else {
//                 tshock_exec(tshock_server(), "/kick " + name + " 亲！你还未注册，请查看群公告！");
//             }
//         })
//     }
// }, "login");