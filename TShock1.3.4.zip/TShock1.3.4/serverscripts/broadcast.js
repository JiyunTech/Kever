var msg = "本服可传送玩家和特殊点.\n";
msg += " /tp 玩家名 可传送到玩家身边\n\n";

msg += " /dp 传送点名 可传送到特定传送点\n";
msg += "输入 /dp ? 获取可用的传送点！\n\n";
jist_run_at(6, 0, function() {
    tshock_broadcast_colour("#F44", msg);
});
jist_run_at(15, 0, function() {
    tshock_broadcast_colour("#F44", msg);
});
jist_run_at(24, 0, function() {
    tshock_broadcast_colour("#F44", msg);
});
